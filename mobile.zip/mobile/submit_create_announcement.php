<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_mobile";
	
	// Get variable that was sent
	$courseNumber = $_POST['courseNumber'];
	$courseName = $_POST['courseName'];
	$instructorName = $_POST['instructorName'];
	$message = $_POST['message'];
	
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "INSERT INTO Announcements (courseNumber, courseName, instructorName, message) VALUES ('" . $courseNumber . "','" . $courseName . "','" . $instructorName . "','" . $message . "')";
	echo '<div class="row">';
		echo '<div class="large-12 columns small-12 small-centered text-center">';
			if ($conn->query($sql) === TRUE) {
				echo '<p class="text-centered">New announcement created successfully</p>';
			} else {
				echo '<p class="text-centered">Error: ' . $sql . '<br />' . $conn->error . '</p>';
			}
		echo '</div>';
	echo '</div>';
	
	$conn->close();
?>