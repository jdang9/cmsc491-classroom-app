<table class="sticky-enabled large-12 columns small-centered">
	<thead>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th class="text-right">ID</th>
			<th class="text-right">Client Count</th>
		</tr>
	</thead>
	<tbody>	

<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "SELECT fname, lname, tech_id, client_count FROM techs";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo '<tr><td class="lname"><a class="tech" id="' . $row['tech_id'] . '">' . $row['lname'] . '</a></td><td class="fname">' . $row['fname'] . '</td><td class="tech_id text-right">' . $row['tech_id'] . '</td><td class="client_count text-right">' . $row['client_count'] . '</td></tr>';
		}
	} else {
		echo "0 results";
	}
	$conn->close();
?>

	</tbody>
</table>

<script>
	$(document).ready(function(){
		$(".tech").click(function(){
			$("#get_query_2").hide();
			$("#get_query_2").load("get_tech_info.php?tech_id=" + $(this).attr('id'), function(){
				$(this).fadeIn(500);
			});
			$("#get_query_2").parent().parent().parent().removeClass("hide");
		});		
	});
</script>