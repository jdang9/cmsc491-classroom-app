<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";
	
	// Get variable that was sent
	$client_id = $_GET['client_id'];
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = 'SELECT clients.client_name, clients.address, clients.cityStateZip, clients.serviceDate1, clients.serviceDate2, clients.email, clients.phone, clients.client_id, clients.tech_id, techs.fname, techs.lname, techs.tech_id, techs.client_count 
			FROM clients, techs 
			WHERE clients.tech_id = techs.tech_id AND clients.client_id=' . $client_id;
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo '<h2>'.$row['client_name'].'</h2><hr />';
			echo '<p><strong>Client ID:</strong> ' . $row['client_id'] . '</p>';
			echo '<p><strong>Tech Assigned:</strong> ' . $row['fname'] . ' ' . $row['lname'] . '</p>';
			echo '<hr />';
			echo '<p><strong>Address:</strong> ' . $row['address'] . ' ' . $row['cityStateZip'] . '</p>';
			echo '<p><strong>Email:</strong> ' . $row['email'] . '</p>';
			echo '<p><strong>Phone:</strong> ' . $row['phone'] . '</p>';
			echo '<p><strong>First Service Date:</strong> ' . $row['serviceDate1'] . '</p>';
			echo '<p><strong>Second Service Date:</strong> ' . $row['serviceDate2'] . '</p>';
		}
	} else {
		echo "0 results";
	}
	$conn->close();
?>