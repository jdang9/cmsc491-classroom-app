<?php

$servername = "jamesfreund.com";
$username = "jfreund_admin";
$password = "Ki8vv3uj";
$dbname = "jfreund_mobile";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM Announcements";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
	$announcements[] = array(
		'id' => $row['id'],
		'courseNumber' => $row['courseNumber'],
		'courseName' => $row['courseName'],
		'instructorName' => $row['instructorName'],
		'message' => $row['message'],
		'regDate' => $row['reg_date']
	);
}


// Create json array
$json = array(
	'announcements' => $announcements
);

// Output to browser
$output = json_encode($json);
echo $output;

?>