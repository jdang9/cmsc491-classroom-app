<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";

	// Get variable that was sent
	$tech_id = $_GET['tech_id'];
	$printed = true;

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
?>