<table class="sticky-enabled large-12 columns small-centered">
	<thead>
		<tr>
			<th>User ID</th>
			<th>Attendance</th>
		</tr>
	</thead>
	<tbody>	

<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_mobile";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "SELECT * FROM Attendance";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo '<tr><td class="user_id">' . $row['uid'] . '</td><td class="attendance">' . $row['attendance'] . '</td></tr>';
		}
	} else {
		echo "0 results";
	}
	$conn->close();
?>

	</tbody>
</table>

<script>
	$(document).ready(function(){
		$(".course").click(function(){
			$("#get_query_2").hide();
			$("#get_query_2").load("get_course_info.php?id=" + $(this).attr('id'), function(){
				$(this).fadeIn(500);
			});
			$("#get_query_2").parent().parent().parent().removeClass("hide");
		});		
	});
</script>