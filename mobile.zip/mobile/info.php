<div class="row">						
	<div id="get_query" class="large-12 columns small-centered">
	</div>
</div>
<div class="row hide">
	<div class="large-12 columns">
		<div class="radius panel">
			<div id="get_query_2" class="large-12 columns small-centered">
			</div>
		</div>
	</div>
</div>
<hr />
<div class="row">
	<div class="large-8 small-12 columns small-centered">
		<div class="large-6 small-12 columns">
			<a href="#" id="get_announcements" class="button special expand radius">List Announcements</a>
		</div>
		<div class="large-6 small-12 columns">
			<a href="#" id="create_announcement" class="button special expand radius">Create Announcement</a>
		</div>
	</div>
</div>

<script src="js/lma.js"></script>