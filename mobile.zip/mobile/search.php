<?php
	/*$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";
	
	// Get variable that was sent
	
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	
	$sql = 'SELECT 
			techs.tech_id, techs.fname, techs.lname, techs.client_count FROM techs WHERE techs.client_count =' . $deciding_value;
	$result = $conn->query($sql);*/
?>
	<div class="row">
		<div class="large-12 columns small-12 small-centered">
			<h6 class="text-center subheader">Not yet implemented</h6>
		</div>
	</div>
<?php	
	/*echo '<div class="row">';
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if ($printed) {
				$printed = false;
			}
		}
	} else {
		echo "0 results";
	}
	
	echo '</div>';
	
	$conn->close();*/
?>

<script src="js/lma.js"></script>