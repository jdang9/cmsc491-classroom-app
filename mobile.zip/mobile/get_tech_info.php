<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";
	
	// Get variable that was sent
	$tech_id = $_GET['tech_id'];
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = 'SELECT clients.client_name, clients.client_id, clients.tech_id, techs.fname, techs.lname, techs.tech_id, techs.client_count 
			FROM clients, techs 
			WHERE clients.tech_id = techs.tech_id AND techs.tech_id=' . $tech_id;
	$result = $conn->query($sql);
	
	echo '<div class="row">';
	
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if ($printed) {
				echo '<h2>' . $row['fname'] . ' ' . $row['lname'] . '</h2><hr />';
				echo '<p><strong>Tech ID:</strong> ' . $row['tech_id'] . '</p>';
				echo '<p><strong>Client Count:</strong> ' . $row['client_count'] . '</p><hr />';
				echo '<h3>Clients:</h3><hr />';
				$printed = false;
			}
			echo '<div class="large-4 columns">';
				echo '<h4>' . $row['client_name'] . '</h4>';
				echo '<h6><strong>Client ID:</strong> ' . $row['client_id'] . '</h6>';
			echo '</div>';
		}
	} else {
		echo "0 results";
	}
	
	echo '</div>';
	
	echo $tech_lname;
	$conn->close();
?>