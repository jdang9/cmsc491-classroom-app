<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin - Web Interface</title>
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
	<link rel="stylesheet" type="text/css" href="css/component.css" />
	<link rel="stylesheet" href="foundation-icons.css" />
	
    <link rel="stylesheet" href="css/foundation.css" />
	
    <script src="js/vendor/modernizr.js"></script>
	
	<script type="text/javascript" src="js/qrcode.js"></script>
  </head>
  <body>  
  
		<div class="row hide" id="navbar">
			<div class="icon-bar four-up radius">
				<a id="home" class="item active">
					<i class="fi-home"></i>
					<label>Home</label>
				</a>
				<a id="courses" class="item">
					<i class="fi-dollar"></i>
					<label>Courses</label>
				</a>
				<a id="info" class="item">
				<i class="fi-info"></i>
				<label>Announcements</label>
				</a>
				<a id="attendance" class="item">
				<i class="fi-lightbulb"></i>
				<label>Attendance</label>
				</a>
				<!--<a id="search" class="item">
				<i class="fi-magnifying-glass"></i>
				<label>Search</label>
				</a>-->
			</div>
		</div>
	
	<div class="row">
		<div class="large-12 columns">
			
			<div id="main" class="radius panel">
				<!--<h2 class="text-center">Functions</h2>-->
				<div class="row">						
					<div id="get_query" class="large-12 columns small-centered">
						<a class="small-centered text-center">
							<img id="logo" src="img/header_logo.png">
						</a>
					</div>
				</div>
				<div class="row hide">
					<div class="large-12 columns">
						<div class="radius panel">
							<div id="get_query_2" class="large-12 columns small-centered">
							</div>
						</div>
					</div>
				</div>
				<hr />
				<div class="row" id="login_form">
					<h6 class="text-center subheader">Required Information</h6>
					<div class="large-8 columns small-12 small-centered">
						<label>User Name<span style="color:red;">*</span>
						<input type="text" name="userName" id="user_name" placeholder="Username" required></label>
						<label>Password<span style="color:red;">*</span>
						<input type="password" name="password" id="password" placeholder="Password" required></label>
					</div>
					<div class="large-3 small-8 columns small-centered">
						<a href="#" id="login" class="button special expand round">Login</a>
					</div>
					
				</div>
				<div class="row hide" id="sign_in_success">
					<h4 class="text-center subheader">You are signed in as <span style="color:#4868AD;">$admin</span>.</h4>
				</div>
			</div>
		</div>
	</div>
		
	<div class="row hide">
		<div class="large-12 columns">
			<div class="radius panel">
			</div>
		</div>
	</div>
	

	</div>
    
    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
	<script src="js/jquery.stickyheader.js"></script>
    <script>
      $(document).foundation();
    </script>
	<script src="js/lma.js"></script>
  </body>
</html>
