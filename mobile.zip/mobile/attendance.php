<div class="row">						
	<div id="get_query" class="large-12 columns small-centered">
	</div>
</div>
<div class="row hide">
	<div class="large-12 columns">
		<div class="radius panel">
			<div id="get_query_2" class="large-12 columns small-centered">
			</div>
		</div>
	</div>
</div>
<hr />
<div class="row">
	<div class="large-12 columns small-centered">
		<div class="large-8 small-12 columns small-centered">
			<div class="large-6 small-12 columns">
				<a href="#" id="show_attendance" class="button special expand radius">Show Attendance</a>
			</div>
			<div class="large-6 small-12 columns">
				<a href="#" id="get_qr" class="button special expand radius">Get QR Code</a>
			</div>
		</div>
	</div>
</div>

<script src="js/lma.js"></script>