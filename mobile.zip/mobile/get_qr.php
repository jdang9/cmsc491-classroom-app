<div class="row">
	<h2 class="text-center subheader">QR Code</h2>
	<div class="large-12 columns small-12 small-centered">
		<div class="large-3 small-12 columns small-centered" id="qrcode"></div>
		<script type="text/javascript">
			new QRCode(document.getElementById("qrcode"), "http://jamesfreund.com/mobile/setAttendance.php");
		</script>
	</div>
</div>

<script src="js/lma.js"></script>