<table class="sticky-enabled large-12 columns small-centered">
	<thead>
		<tr>
			<th>Client Name</th>
			<th>Client ID</th>
			<th>Tech First Name</th>
			<th>Tech Last Name</th>
		</tr>
	</thead>
	<tbody>	

<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "SELECT clients.client_name, clients.client_id, clients.tech_id, techs.fname, techs.lname, techs.tech_id, techs.client_count FROM clients, techs WHERE clients.tech_id = techs.tech_id";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo '<tr><td class="client_name"><a class="client" id="' . $row['client_id'] . '">' . $row['client_name'] . '</a></td><td class="client_id">' . $row['client_id'] . '</td><td class="fname">' . $row['fname'] . '</td><td class="lname">' . $row['lname'] . '</td></tr>';
		}
	} else {
		echo "0 results";
	}
	$conn->close();
?>

	</tbody>
</table>
<script>
	$(document).ready(function(){
		$(".client").click(function(){
			$("#get_query_2").hide();
			$("#get_query_2").load("get_client_info.php?client_id=" + $(this).attr('id'), function(){
				$(this).fadeIn(500);
			});
			$("#get_query_2").parent().parent().parent().removeClass("hide");
		});		
	});
</script>