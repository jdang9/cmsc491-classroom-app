<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_mobile";
	
	// Get variable that was sent
	$id = $_GET['id'];
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = 'SELECT 
			Announcements.id, Announcements.courseNumber, Announcements.courseName, Announcements.instructorName, Announcements.message, Announcements.reg_date
			FROM
			Announcements
			WHERE Announcements.id = ' . $id;
	$result = $conn->query($sql);
	
	echo '<div class="row">';
	
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if ($printed) {
				$printed = false;
			}
			echo '<div class="row">';
				echo '<div class="large-12 small-12 columns">';
					echo '<h4>' . $row['reg_date'] . '</h4><hr />';
					echo '<p><strong>Course Name: </strong>' . $row['courseName'] . '<small> (' . $row['courseNumber'] . ')</small></p>';
					echo '<p><strong>Instructor: </strong>' . $row['instructorName'] . '</p>';
					
					echo '<p><strong>Message: </strong>' . $row['message'] . '</p>';
				echo '</div>';
			echo '</div>';
			
		}
	} else {
		echo "0 results";
	}
	
	echo '</div>';
	$conn->close();
?>