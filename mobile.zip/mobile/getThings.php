<?php

$servername = "jamesfreund.com";
$username = "jfreund_admin";
$password = "Ki8vv3uj";
$dbname = "jfreund_mobile";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM Courses";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
	$courses[] = array(
		'id' => $row['id'],
		'courseNumber' => $row['courseNumber'],
		'courseName' => $row['courseName'],
		'instructorName' => $row['instructorName'],
		'courseTime' => $row['courseTime'],
		'courseDays' => $row['courseDays']
	);
}


// Create json array
$json = array(
	'courses' => $courses
);

// Output to browser
$output = json_encode($json);
echo $output;

?>