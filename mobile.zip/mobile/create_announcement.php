<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_mobile";
	
	// Get variable that was sent
	
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	
	/*$sql = 'SELECT * FROM clients';
	$result = $conn->query($sql);
	$num_clients = $result->num_rows;
	
	$sql = 'SELECT * FROM techs';
	$result = $conn->query($sql);
	$num_techs = $result->num_rows;*/
	
	//$sql = 'SELECT clients.client_id, clients.client_name, clients.address, clients.cityStateZip FROM clients';
	//$result = $conn->query($sql);
?>
	<form>
		<div class="row">
			<h6 class="text-center subheader">Required Information</h6>
			<div class="large-12 columns small-12 small-centered">
				<label>Course Number<span style="color:red;">*</span>
				<input type="text" name="courseNumber" id="course_number" placeholder="CMSC101" required></label>
				<label>Course Name<span style="color:red;">*</span>
				<input type="text" name="courseName" id="course_name" placeholder="Introduction to Computer Science" required></label>
				<label>Course Instructor<span style="color:red;">*</span>
				<input type="text" name="instructorName" id="instructor_name" placeholder="Resler" required></label>
				<label>Message<span style="color:red;">*</span>
				<textarea rows="10" name="message" id="message" placeholder="Insert message..." required></textarea></label>
			</div>
			<hr />
		</div>
		<div class="row">
			<div class="large-3 small-8 columns small-centered">
				<a href="#" id="submit_announcement" class="button special expand round">Submit</a>
			</div>
		</div>
	
	</form>
<?php		
	$conn->close();
?>

<script src="js/lma.js"></script>