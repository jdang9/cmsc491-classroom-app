<?php
	$servername = "jamesfreund.com";
	$username = "jfreund_admin";
	$password = "Ki8vv3uj";
	$dbname = "jfreund_lma";
	
	// Get variable that was sent
	$clientname = $_POST['clientname'];
	$address = $_POST['address'];
	$cityStateZip = $_POST['cityStateZip'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$tech = $_POST['tech'];
	$serviceDate1 = $_POST['serviceDate1'];
	$serviceDate2 = $_POST['serviceDate2'];
	
	$printed = true;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "INSERT INTO clients (client_name, address, cityStateZip, email, phone, tech_id, serviceDate1, serviceDate2) VALUES ('" . $clientname . "','" . $address . "','" . $cityStateZip . "','" . $email . "','" . $phone . "','" . $tech . "','" . $serviceDate1 . "','" . $serviceDate2 . "')";
	echo '<div class="row">';
		echo '<div class="large-12 columns small-12 small-centered text-center">';
			if ($conn->query($sql) === TRUE) {
				echo '<p class="text-centered">New client created successfully</p>';
			} else {
				echo '<p class="text-centered">Error: ' . $sql . '<br />' . $conn->error . '</p>';
			}
			$sql = 'UPDATE techs SET client_count=(1 + client_count) WHERE tech_id='.$tech;
			if ($conn->query($sql) === TRUE) {
				echo '<p class="text-centered">and tech client count updated</p>';
			} else {
				echo '<p class="text-centered">Error: ' . $sql . '<br />' . $conn->error . '</p>';
			}
		echo '</div>';
	echo '</div>';
	
	$conn->close();
?>