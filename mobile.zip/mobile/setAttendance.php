<?php

// Set the database access information
$servername = "jamesfreund.com";
$username = "jfreund_admin";
$password = "Ki8vv3uj";
$dbname = "jfreund_mobile";
		
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$found = false;
$attendance_count = 0;
$found_uid = 0;

$sql = "SELECT * FROM Attendance";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
	if ($row['uid'] == $_POST['uid']) {
		$attendance_count = $row['attendance'];
		$found = true;
		$found_uid = $row['uid'];
	}
}

$attendance_count = $attendance_count + 1;

if ($found == true) {
	$sql = "UPDATE Attendance SET attendance='".$attendance_count."' WHERE uid='".$found_uid."'";
	$result = $conn->query($sql);
	
	// Success status
	$status = 'success updated';
}

else {
	// POST
	$sql = "INSERT INTO Attendance (uid , attendance) VALUES ('" . $_POST['uid'] . "', 1)";
	$result = $conn->query($sql);

	// Success status
	$status = 'success inserted';
}

// Create json array
$json = array(
	'status' => $attendance_count
);

// Output to browser
$output = json_encode($json);
echo $output;

$conn->close();

?>